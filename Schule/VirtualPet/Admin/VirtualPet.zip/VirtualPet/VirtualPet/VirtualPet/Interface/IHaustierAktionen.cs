﻿namespace VirtualPet.Interface;

public interface IHaustierAktionen
{
    void Fuettern();
    void Spaziergang();
    void Schlafen();
    void ReagiereAufAktion();
}